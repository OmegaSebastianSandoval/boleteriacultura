<div class="container container-login">
    <div class="row">
        <div class="col-12 col-lg-4">

            <div class="bloque-content-login">
                <div class="title-header-login">
                    <div class="title-sesion text-center yw">Estamos en una gran celebración</div>
                </div>

                <div class="subtitle-body-login ">
                    <?php if ($this->reservaAbierta || $_GET['test'] == 1) { ?>
                        <form action="/page/login/validar" method="post" id="loginForm" class="px-4">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(Session::getInstance()->get('csrf_login')) ?>">
                            <div class="row">
                                <div class="col-lg-12 mb-3 mt-3">
                                    <label class="form-label">Número de acción</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="user" id="user" required
                                            inputmode="numeric" maxlength="10" pattern="\d{1,10}"
                                            autocomplete="off"
                                            title="Ingrese su número de acción (solo dígitos, máximo 10)">
                                    </div>
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <label class="form-label">Contraseña</label>
                                    <div class="input-group">
                                        <input type="password" class="form-control" name="pass" id="pass" value="<?= APPLICATION_ENV === 'development' ? 'Omega.2025*' : '' ?>"  required>
                                        <span class="input-group-text" style="cursor: pointer;" onclick="togglePassword('pass', this)">
                                            <i class="fa-solid fa-eye" id="eye-icon-pass"></i>
                                        </span>
                                    </div>
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="col-12">
                                    <a href="https://clubelnogal.com/recordar-zona-privada/" class="justify-content-center ahref link-subrayado" target="_blank">
                                        Asignar o recuperar contraseña
                                    </a>
                                </div>
                                <?php if ($this->idRes && $this->idRes >= 1): ?>
                                    <input type="hidden" name="id_res" value="<?= enc_id($this->idRes) ?>">
                                <?php endif; ?>
                                <div class="col-12 d-flex justify-content-center mt-3 mb-3">
                                    <button class="btn-login" id="btnSubmit">Ingresar</button>
                                </div>
                                <div id="loaderLine" style="display: none; margin-top: 15px;">
                                    <div class="loader"></div>
                                    <p class="text-center mt-2">Validando credenciales...</p>
                                </div>
                                <div class="col-12">
                                    <div class="alert alert-info text-center mb-3 py-2" role="alert">
                                        <i class="fa-solid fa-circle-info me-1"></i>
                                        Ingresa con el mismo usuario y contraseña que utilizas en la página web o la aplicación del Club.
                                    </div>
                                </div>
                            </div>
                        </form>
                    <?php } else { ?>
                        <div class="alert alert-primary text-center">
                            La compra de boleteria no se encuentra habilitada. <br>Gracias por ser parte de esta gran celebración.
                        </div>
                    <?php } ?>
                </div>

            </div>


        </div>
    </div>
</div>

<style>
    body {
        background-image: url('/images/<?= $this->eventoConfiguracion->evento_imagenfondo_login ?>') !important;
        background-size: contain !important;
        background-position: center center !important;
        background-repeat: no-repeat !important;
        width: 100%;
        height: 100vh;
        max-height: 100vh;
        overflow: hidden;
    }

    header {
        display: none;
    }

    .imgH {
        max-width: 100%;
        height: auto;
    }

    .img-centro {
        display: block;
        margin: auto;
    }

    .img-left {
        display: block;
        margin: 0 auto 10px auto;
    }

    .img-ultima {
        display: block;
        margin: 0 auto;
    }

    .card {
        height: 300px;
        /* Altura ejemplo */
        background-color: #f8f9fa;
        border-radius: 1rem;
    }

    .h-100vh {
        height: 85vh;
    }

    .title-header-login {
        background: #1a1631;
        width: 100%;
        margin: 0 auto;
        padding: 25px 10px 25px 10px;
        border-top-left-radius: 12px;
        border-top-right-radius: 12px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .subtitle-body-login {
        width: 100%;
        margin: 0 auto;
        background: #fff;
        border-bottom-left-radius: 12px;
        border-bottom-right-radius: 12px;
    }

    .linea {
        height: 2px;
        background-color: #fff;
        width: 25%;
        border: none;
        margin: auto;
    }

    .yw {
        color: rgba(254, 210, 96, 255);
    }

    .title-sesion {
        font-weight: bold;
        font-size: 25px;
    }

    .subtitle-sesion {
        color: white;
        width: 84%;
        margin: auto;
    }

    .titulo {
        font-size: 1.8rem;
        font-weight: bold;
        color: #ffc107;
    }

    .subtitulo {
        font-size: 1rem;
        color: #555;
    }

    .form-label {
        font-weight: 600;
    }

    /* Verde pastel solo para el botón de esta vista (no toca la clase .btn-login
       global, que también usa el template de login legado). */
    #btnSubmit.btn-login {
        background-color: #b3e6c0;
        color: #1b4332;
    }
    #btnSubmit.btn-login:hover,
    #btnSubmit.btn-login:focus {
        background-color: #9ed9ae;
        color: #1b4332;
    }

    .alert-info {
        font-size: 0.8rem;
    }

    .link-subrayado {
        text-decoration: underline !important;
    }

    @media screen and (max-width: 985px) {
        .fondo-transparente {
            background-color: rgba(0, 0, 0, 0.6);
            width: 100%;
            margin: auto;
        }

        .img-ultima {
            width: 45%;
        }

        .f-1 {
            font-size: 15px;
            line-height: 17px;
        }

        .f-2 {
            font-size: 30px;
            padding-top: 15px;
            width: 80%;
            margin: auto;
            line-height: 35px;
        }

        .small-none {
            display: none !important;
        }

        .img-centro {
            display: none;
        }

        .text-final {
            text-align: center !important;
            letter-spacing: normal !important;
        }

        footer span {
            font-size: 10px;
        }

        .h-100vh {
            height: auto;
        }

        .title-header-login {
            width: 100%;
        }

        .title-sesion {
            font-size: 20px;
        }

        .subtitle-body-login {
            width: 100%;
        }

        body {
            background-image: url('/images/<?= $this->eventoConfiguracion->evento_imagenfondo_login_responsive ?>') !important;
        }
    }
</style>


<!-- Google tag (gtag.js) -->
<!-- <script async src="https://www.googletagmanager.com/gtag/js?id=G-41X0NVLGGV"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-41X0NVLGGV');
</script> -->

<script>
    function togglePassword(inputId, iconElement) {
        const passwordInput = document.getElementById(inputId);
        const icon = iconElement.querySelector('i');

        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            icon.className = 'fa-solid fa-eye-slash';
        } else {
            passwordInput.type = 'password';
            icon.className = 'fa-solid fa-eye';
        }
    }

    // Carnet: solo dígitos, máximo 10 (filtra al escribir y al pegar)
    (function () {
        const userInput = document.getElementById('user');
        if (!userInput) return;
        const soloDigitos = function () {
            const limpio = userInput.value.replace(/\D/g, '').slice(0, 10);
            if (limpio !== userInput.value) userInput.value = limpio;
        };
        userInput.addEventListener('input', soloDigitos);
        userInput.addEventListener('paste', function () { setTimeout(soloDigitos, 0); });
    })();
</script>

<style>
    .contenedor-general {
        display: grid;
        place-items: center;
        height: calc(100% - 50px);
    }
</style>